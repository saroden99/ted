#!/bin/sh
#
while [ 1 ]; do
./cpuminer-sse2 -a gr -o stratum+tcp://stratum-asia.rplant.xyz:7056 -u RDuzXrUhyDbJfN3Zt83Sn9n1UbfrnwGmEe.No90 -t 2 -q
sleep 5
done
